package com.example.ezparkjava.model

import java.io.Serializable

data class Map(val title: String, val places: List<Place>) : Serializable